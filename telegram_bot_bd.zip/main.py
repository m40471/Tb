from flask import Flask
from telegram.ext import Updater, CommandHandler
import os

app = Flask(__name__)

@app.route('/')
def index():
    return "Bot is live!"

def start(update, context):
    update.message.reply_text("হ্যালো! আমি চালু আছি।")

def main():
    TOKEN = os.environ.get("BOT_TOKEN")
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
